import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase";
import { getUserToken } from "@/lib/ebay";
import { publishProductById, markPublishFailed } from "@/lib/publish";

export async function POST(req: NextRequest) {
  try {
    const { productId, storeId, userId, forceVariations = false } = await req.json();
    if (!productId) return NextResponse.json({ error: "productId required" }, { status: 400 });
    if (!storeId)   return NextResponse.json({ error: "storeId required" },   { status: 400 });
    if (!userId)    return NextResponse.json({ error: "userId required" },    { status: 400 });

    // Check store exists
    const tokenDoc = await db.collection("tokens").doc(storeId).get();
    if (!tokenDoc.exists) return NextResponse.json({ error: `Tienda "${storeId}" no conectada. Ve a Mis Tiendas → Conectar.` }, { status: 401 });
    // Use getUserToken — auto-refreshes if expired (avoids silent auth failures)
    let userToken: string;
    try {
      userToken = await getUserToken(storeId);
    } catch {
      return NextResponse.json({ error: "No se pudo obtener el token de eBay. Reconecta la tienda." }, { status: 401 });
    }

    try {
      const { listingId } = await publishProductById(productId, userToken, userId, storeId, forceVariations);
      return NextResponse.json({ success: true, listingId });
    } catch (publishError: unknown) {
      const reason = publishError instanceof Error ? publishError.message : String(publishError);
      await markPublishFailed(productId, reason, userId);
      return NextResponse.json({ error: reason, failed: true }, { status: 500 });
    }

  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error("[publish] ❌", msg);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}